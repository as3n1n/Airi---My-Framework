#include "pch.h"
#include "cheat.h"
#include "engine.h"
#include "global.h"
#include "imgui.h"
#include "config.h"
#include "fov_changer.h"
#include "fps_indicator.h"
#include "fps_unlocker.h"
#include "global_speed_changer.h"
#include "menu_settings.h"

namespace Cheat
{
	static HOOK s_Hook = {};

	static HMODULE DetourLLE(LPCWSTR lib, HANDLE hf, DWORD fl)
	{
		HMODULE hm = CALL_ORIGINAL(s_Hook, DetourLLE, lib, hf, fl);
		if (!hIl2Cpp)
		{
			if (hm && hm == GetModuleHandleW(L"GameAssembly.dll"))
			{
				hIl2Cpp = hm;
				Config::Setup();
				FovChanger::Setup();
				FpsIndicator::Setup();
				FpsUnlocker::Setup();
				GlobalSpeedChanger::Setup();
				MenuSettings::Setup();
			}
		}
		return hm;
	}

	void MenuVisuals()
	{
		FovChanger::Menu();
		ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
		FpsIndicator::Menu();
		ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
		MenuPerfOverlay();
	}

	void MenuMisc()
	{
		FpsUnlocker::Menu();
		ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
		GlobalSpeedChanger::Menu();
		ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
		Config::Menu();
	}

	void MenuSettings()
	{
		MenuSettings::Menu();
		ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
		Config::MenuConfigProfiles();
	}

	void BeforeFrame()
	{
		FovChanger::BeforeFrame();
		FpsIndicator::BeforeFrame();
		FpsUnlocker::BeforeFrame();
		GlobalSpeedChanger::BeforeFrame();
		MenuSettings::BeforeFrame();
		Config::BeforeFrame();
	}

	void OnFrame()
	{
		FovChanger::OnFrame();
		FpsIndicator::OnFrame();
		FpsUnlocker::OnFrame();
		GlobalSpeedChanger::OnFrame();
		MenuSettings::OnFrame();
		Config::OnFrame();
		Aimbot_OnFrame();
		ESP_OnFrame();
		Misc_OnFrame();
		PerfOverlay_OnFrame();
	}

	bool Setup()
	{
		// Fix : GameAssembly.dll peut déjà être chargée si injection tardive
		HMODULE hAlready = GetModuleHandleW(L"GameAssembly.dll");
		if (hAlready)
		{
			hIl2Cpp = hAlready;
			Config::Setup();
			FovChanger::Setup();
			FpsIndicator::Setup();
			FpsUnlocker::Setup();
			GlobalSpeedChanger::Setup();
			MenuSettings::Setup();
		}

		HMODULE hKB = GetModuleHandleW(L"kernelbase.dll"); if (!hKB) return FALSE;
		if (!IsHookActive(&s_Hook) &&
			!CreateHook(&s_Hook, GetProcAddress(hKB, "LoadLibraryExW"), DetourLLE, TRUE))
			return FALSE;
		return TRUE;
	}
}