#pragma once
#include <windows.h>
#include <stdint.h>

extern HMODULE hIl2Cpp;

// ── Il2Cpp helpers ────────────────────────────────────────────────────────
inline Il2CppClass* RM2_GetClass(int32_t typeDefIdx)
{
    if (!hIl2Cpp) return nullptr;
    return ((Il2CppClass * (*)(int32_t))((PBYTE)hIl2Cpp + 0x1A67EF0))(typeDefIdx);
}

inline void* RM2_GetStaticField(Il2CppClass* c, uint32_t offset)
{
    if (!c) return nullptr;
    void* sf = c->static_fields;
    if (!sf) return nullptr;
    return (PBYTE)sf + offset;
}