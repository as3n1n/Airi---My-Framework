#pragma once
#include <windows.h>
#include "hook.h"

namespace Cheat
{
    void MenuAimbot();
    void MenuESP();
    void MenuMiscFeatures();
    void MenuVisuals();
    void MenuMisc();
    void MenuSettings();
    void MenuPerfOverlay(); // ← ajouter

    void ESP_OnFrame();
    void Aimbot_OnFrame();
    void Misc_OnFrame();
    void PerfOverlay_OnFrame();

    void BeforeFrame();
    void OnFrame();
    bool Setup();
}