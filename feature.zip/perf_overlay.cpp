#include "pch.h"
#include "cheat.h"
#include "engine.h"
#include "global.h"
#include "imgui.h"
#include "imgui_user.h"
#include <windows.h>
#include <psapi.h>
#include <stdio.h>
#pragma comment(lib, "psapi.lib")

namespace Cheat
{
	static bool  PerfOverlay_Enable = true;
	static bool  PerfOverlay_ShowFPS = true;
	static bool  PerfOverlay_ShowMS = true;
	static bool  PerfOverlay_ShowRAM = true;
	static bool  PerfOverlay_ShowBudget = true;
	static int   PerfOverlay_Corner = 1;
	static float PerfOverlay_BgAlpha = 0.55f;

	static float s_FpsHistory[90] = {};
	static int   s_FpsHistoryIdx = 0;
	static float s_FpsUpdateTimer = 0.0f;

	static float GetRAM_MB()
	{
		PROCESS_MEMORY_COUNTERS pmc = {};
		pmc.cb = sizeof(pmc);
		if (GetProcessMemoryInfo(GetCurrentProcess(), &pmc, sizeof(pmc)))
			return (float)(pmc.WorkingSetSize) / (1024.0f * 1024.0f);
		return 0.0f;
	}

	void PerfOverlay_OnFrame()
	{
		if (!PerfOverlay_Enable) return;

		ImGuiIO& io = ImGui::GetIO();
		float dt = io.DeltaTime;
		float fps = io.Framerate;
		float ms = dt * 1000.0f;

		s_FpsUpdateTimer += dt;
		if (s_FpsUpdateTimer >= 0.05f)
		{
			s_FpsHistory[s_FpsHistoryIdx] = fps;
			s_FpsHistoryIdx = (s_FpsHistoryIdx + 1) % 90;
			s_FpsUpdateTimer = 0.0f;
		}

		const float PAD = 8.0f;
		ImVec2 vp = io.DisplaySize;
		ImVec2 pos, pivot;
		switch (PerfOverlay_Corner)
		{
		default:
		case 0: pos = { PAD,        PAD }; pivot = { 0, 0 }; break;
		case 1: pos = { vp.x - PAD, PAD }; pivot = { 1, 0 }; break;
		case 2: pos = { PAD,        vp.y - PAD }; pivot = { 0, 1 }; break;
		case 3: pos = { vp.x - PAD, vp.y - PAD }; pivot = { 1, 1 }; break;
		}

		ImGui::SetNextWindowPos(pos, ImGuiCond_Always, pivot);
		ImGui::SetNextWindowBgAlpha(PerfOverlay_BgAlpha);
		ImGui::SetNextWindowSize(ImVec2(180.0f, 0.0f));

		ImGuiWindowFlags flags =
			ImGuiWindowFlags_NoDecoration |
			ImGuiWindowFlags_NoInputs |
			ImGuiWindowFlags_NoNav |
			ImGuiWindowFlags_NoMove |
			ImGuiWindowFlags_NoSavedSettings |
			ImGuiWindowFlags_NoBringToFrontOnFocus |
			ImGuiWindowFlags_AlwaysAutoResize;

		ImGui::PushStyleColor(ImGuiCol_WindowBg,
			ImVec4(0.04f, 0.01f, 0.01f, PerfOverlay_BgAlpha));
		ImGui::PushStyleColor(ImGuiCol_Border,
			ImVec4(0.28f, 0.05f, 0.05f, 0.80f));

		if (ImGui::Begin("##PerfOvr", nullptr, flags))
		{
			if (PerfOverlay_ShowFPS)
			{
				ImVec4 fpsCol = fps >= 55 ?
					ImVec4(0.30f, 0.85f, 0.30f, 1.0f) :
					fps >= 30 ?
					ImVec4(0.95f, 0.75f, 0.10f, 1.0f) :
					ImVec4(0.90f, 0.15f, 0.15f, 1.0f);
				ImGui::PushStyleColor(ImGuiCol_Text, fpsCol);
				ImGui::Text("FPS  %.0f", fps);
				ImGui::PopStyleColor();
			}
			if (PerfOverlay_ShowMS)
			{
				ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.75f, 0.60f, 0.60f, 1.0f));
				ImGui::Text("MS   %.2f", ms);
				ImGui::PopStyleColor();
			}
			if (PerfOverlay_ShowBudget)
			{
				float budget = (ms / 16.67f) * 100.0f;
				ImVec4 bCol = budget < 80 ?
					ImVec4(0.30f, 0.85f, 0.30f, 1.0f) :
					budget < 100 ?
					ImVec4(0.95f, 0.75f, 0.10f, 1.0f) :
					ImVec4(0.90f, 0.15f, 0.15f, 1.0f);
				ImGui::PushStyleColor(ImGuiCol_Text, bCol);
				ImGui::Text("Budget %.0f%%", budget);
				ImGui::PopStyleColor();
			}
			if (PerfOverlay_ShowRAM)
			{
				float ram = GetRAM_MB();
				ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.75f, 0.60f, 0.60f, 1.0f));
				ImGui::Text("RAM  %.0f MB", ram);
				ImGui::PopStyleColor();
			}

			ImGui::Spacing();
			char ovlLabel[32];
			sprintf_s(ovlLabel, sizeof(ovlLabel), "%.0f fps", fps);
			ImGui::PushStyleColor(ImGuiCol_PlotLines, ImVec4(0.85f, 0.14f, 0.14f, 1.0f));
			ImGui::PushStyleColor(ImGuiCol_FrameBg, ImVec4(0.06f, 0.01f, 0.01f, 0.8f));
			ImGui::PlotLines("##fps", s_FpsHistory, 90, s_FpsHistoryIdx,
				ovlLabel, 0.0f, 200.0f, ImVec2(-FLT_MIN, 36.0f));
			ImGui::PopStyleColor(2);
		}
		ImGui::End();
		ImGui::PopStyleColor(2);
	}

	void MenuPerfOverlay()
	{
		ImGui::Toggle("Enable Performance Overlay", &PerfOverlay_Enable);
		ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();

		ImGui::BeginGroupPanel("Display", ImVec2(-FLT_MIN, 0.0f));
		ImGui::Toggle("FPS", &PerfOverlay_ShowFPS);
		ImGui::Toggle("Frame Time", &PerfOverlay_ShowMS);
		ImGui::Toggle("Frame Budget", &PerfOverlay_ShowBudget);
		ImGui::Toggle("RAM Usage", &PerfOverlay_ShowRAM);
		ImGui::EndGroupPanel();

		ImGui::Spacing();
		ImGui::BeginGroupPanel("Position", ImVec2(-FLT_MIN, 0.0f));
		ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1.00f));
		ImGui::TextUnformatted("Corner"); ImGui::PopStyleColor(); ImGui::SameLine();
		ImGui::RadioButton("TL", &PerfOverlay_Corner, 0); ImGui::SameLine();
		ImGui::RadioButton("TR", &PerfOverlay_Corner, 1); ImGui::SameLine();
		ImGui::RadioButton("BL", &PerfOverlay_Corner, 2); ImGui::SameLine();
		ImGui::RadioButton("BR", &PerfOverlay_Corner, 3);
		ImGui::Spacing();
		ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1.00f));
		ImGui::Text("Background"); ImGui::PopStyleColor(); ImGui::SameLine();
		ImGui::SetNextItemWidth(150.0f);
		ImGui::SliderFloat("##PerfBg", &PerfOverlay_BgAlpha, 0.0f, 1.0f, "%.2f");
		ImGui::EndGroupPanel();
	}
} // namespace Cheat