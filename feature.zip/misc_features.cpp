#include "pch.h"
#include "cheat.h"
#include "rm2_helpers.h"
#include "global.h"
#include "imgui.h"
#include "imgui_user.h"
#include <math.h>

namespace Cheat
{
	bool          MISC_NoSpread = false;
	bool          MISC_NoMultSpread = false;
	bool          MISC_NoCamShake = false;
	bool          MISC_RapidFire = false;
	bool          MISC_RapidHit = false;
	bool          MISC_FastReload = false;
	bool          MISC_InfAmmo = false;
	bool          MISC_AlwaysScope = false;
	bool          MISC_MegaDamage = false;
	float         MISC_DmgMult = 10.0f;
	bool          MISC_GodMode = false;
	bool          MISC_HighSpeed = false;
	float         MISC_SpeedMult = 3.0f;
	bool          MISC_AutoSprint = false;
	bool          MISC_NoGravity = false;
	bool          MISC_NoClip = false;
	float         MISC_NoClipSpeed = 20.0f;
	bool          MISC_Spammer = false;
	char          MISC_SpamMsg[256] = "gg";
	float         MISC_SpamDelay = 1.5f;
	float         MISC_SpamTimer = 0.0f;
	unsigned char MISC_GetModKey = 0;
	bool          MISC_ModKeyHeld = false;
	bool          MISC_GravUpdate = false;
	float         MISC_GravY = -9.81f;

	static void PatchWeapon(RM2_PC* pc)
	{
		if (!pc) return;
		Item_array* items = pc->fields.items;
		if (!items) return;

		for (il2cpp_array_size_t i = 0; i < items->max_length; i++)
		{
			Item_o* item = items->m_Items[i]; if (!item) continue;
			ItemInfo_o* info = item->fields.info; if (!info) continue;
			ItemInfo_ShotInfo_o* shot = info->fields.primaryShotInfo; if (!shot) continue;

			if (MISC_NoSpread)
			{
				shot->fields.bulletSpread = 0.0f;
				shot->fields.adsBulletSpread = 0.0f;
				info->fields.normalSpread = 0.0f;
				info->fields.adsSpread = 0.0f;
				item->fields.bulletSpread = 0.0f;
				pc->fields.bulletSpread = 0.0f;
			}
			if (MISC_NoMultSpread)
				info->fields.movementSpreadMultiplier = 0.0f;

			if (MISC_NoCamShake)
			{
				shot->fields.cameraShake = 0.0f;
				shot->fields.adsCameraShake = 0.0f;
			}
			if (MISC_RapidFire)
			{
				item->fields.nextTimeToUse = 0.0f;
				info->fields.useDelay = 0.0f;
			}
			if (MISC_FastReload)
				info->fields.reloadTime = 0.01f;

			if (MISC_InfAmmo)
			{
				RM_W<int>(item, ITEM_AMMO, 9999);
				RM_W<int>(item, ITEM_TOTAL_AMMO, 9999);
			}
			if (MISC_AlwaysScope)
				info->fields.noscope = true;

			if (MISC_MegaDamage)
				shot->fields.damageMultiplier = MISC_DmgMult;
		}
	}

	static void ApplyGod(RM2_PC* pc)
	{
		RM2_GO* go = pc->fields.cameraHolder; if (!go) return;
		RM2_HS* hs = RM_GetHS(go);            if (!hs) return;
		hs->fields.health = hs->fields.maxHealth;
	}

	static void ApplySpeed(float scale)
	{
		RM2_RB* rb = RM_GetRB(); if (!rb) return;
		RM2_Vec3 v = RM_RB_GetVel(rb);
		float h = sqrtf(v.fields.x * v.fields.x + v.fields.z * v.fields.z);
		if (h > 0.1f)
		{
			v.fields.x *= scale;
			v.fields.z *= scale;
			RM_RB_SetVel(rb, v);
		}
	}

	static void ApplyNoClip()
	{
		RM2_RB* rb = RM_GetRB(); if (!rb) return;
		RM_RB_Kinema(rb, true);
		RM_RB_Gravity(rb, false);
		RM2_Vec3 v = {};
		if (GetAsyncKeyState(VK_SPACE) & 0x8000) v.fields.y = MISC_NoClipSpeed;
		if (GetAsyncKeyState(VK_CONTROL) & 0x8000) v.fields.y = -MISC_NoClipSpeed;
		RM_RB_SetVel(rb, v);
	}

	static void ApplyGravUpdate()
	{
		if (!hIl2Cpp) return;
		RM2_Vec3 g = {};
		g.fields.y = MISC_GravY;
		((void(*)(RM2_Vec3*))((PBYTE)hIl2Cpp + 0x22513A0))(&g);
	}

	void Misc_OnFrame()
	{
		if (!hIl2Cpp) return;
		RM2_PC* pc = RM_GetLocalPC(); if (!pc) return;

		PatchWeapon(pc);

		if (MISC_GodMode) ApplyGod(pc);

		RM2_RB* rb = RM_GetRB();
		if (MISC_NoGravity && rb) RM_RB_Gravity(rb, false);
		if (MISC_NoClip)          ApplyNoClip();
		if (MISC_HighSpeed)       ApplySpeed(MISC_SpeedMult);
		if (MISC_AutoSprint)      ApplySpeed(1.4f);
		if (MISC_GravUpdate)      ApplyGravUpdate();

		if (MISC_Spammer)
		{
			MISC_SpamTimer += ImGui::GetIO().DeltaTime;
			if (MISC_SpamTimer >= MISC_SpamDelay) MISC_SpamTimer = 0.0f;
		}

		if (MISC_GetModKey)
		{
			bool d = (GetAsyncKeyState(MISC_GetModKey) & 0x8000) != 0;
			if (d && !MISC_ModKeyHeld)  MISC_ModKeyHeld = true;
			else if (!d)                MISC_ModKeyHeld = false;
		}
	}

	void MenuMiscFeatures()
	{
		ImGui::BeginGroupPanel("Weapon", ImVec2(-FLT_MIN, 0));
		ImGui::Toggle("No Spread", &MISC_NoSpread);
		ImGui::Toggle("No Multiplier Spread", &MISC_NoMultSpread);
		ImGui::Toggle("No Camera Shake", &MISC_NoCamShake);
		ImGui::Toggle("Rapid Fire", &MISC_RapidFire);
		ImGui::Toggle("Rapid Hit", &MISC_RapidHit);
		ImGui::Toggle("Fast Reload", &MISC_FastReload);
		ImGui::Toggle("Infinity Ammo", &MISC_InfAmmo);
		ImGui::Toggle("Always No Scope", &MISC_AlwaysScope);
		ImGui::Spacing();
		ImGui::Toggle("Mega Damage", &MISC_MegaDamage);
		if (MISC_MegaDamage)
		{
			ImGui::SameLine();
			ImGui::SetNextItemWidth(110);
			ImGui::SliderFloat("##DM", &MISC_DmgMult, 1, 1000, "x%.0f");
		}
		ImGui::EndGroupPanel();

		ImGui::Spacing();
		ImGui::BeginGroupPanel("Player", ImVec2(-FLT_MIN, 0));
		ImGui::Toggle("God Mode", &MISC_GodMode);
		ImGui::Toggle("High Speed", &MISC_HighSpeed);
		if (MISC_HighSpeed)
		{
			ImGui::SameLine();
			ImGui::SetNextItemWidth(100);
			ImGui::SliderFloat("##HS", &MISC_SpeedMult, 1, 20, "x%.1f");
		}
		ImGui::Toggle("Auto Sprint", &MISC_AutoSprint);
		ImGui::Toggle("No Gravity", &MISC_NoGravity);
		ImGui::Toggle("Gravity Update", &MISC_GravUpdate);
		if (MISC_GravUpdate)
		{
			ImGui::Spacing();
			ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1));
			ImGui::Text("Gravity Y"); ImGui::PopStyleColor(); ImGui::SameLine();
			ImGui::SetNextItemWidth(120);
			ImGui::SliderFloat("##GY", &MISC_GravY, -50.0f, 50.0f, "%.1f");
		}
		ImGui::Toggle("NoClip", &MISC_NoClip);
		if (MISC_NoClip)
		{
			ImGui::SameLine();
			ImGui::SetNextItemWidth(100);
			ImGui::SliderFloat("##NCS", &MISC_NoClipSpeed, 5, 100, "%.0f");
		}
		ImGui::EndGroupPanel();

		ImGui::Spacing();
		ImGui::BeginGroupPanel("Other", ImVec2(-FLT_MIN, 0));
		ImGui::Toggle("Spammer", &MISC_Spammer);
		if (MISC_Spammer)
		{
			ImGui::SetNextItemWidth(-FLT_MIN);
			ImGui::InputText("##Sptxt", MISC_SpamMsg, sizeof(MISC_SpamMsg));
			ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1));
			ImGui::Text("Interval"); ImGui::PopStyleColor(); ImGui::SameLine();
			ImGui::SetNextItemWidth(120);
			ImGui::SliderFloat("##SpD", &MISC_SpamDelay, 0.1f, 5.0f, "%.1f s");
		}
		ImGui::Spacing();
		ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1));
		ImGui::Text("Get Mod Key"); ImGui::PopStyleColor(); ImGui::SameLine();
		ImGui::SmallHotkey("##GMK", &MISC_GetModKey);
		ImGui::EndGroupPanel();
	}
} // namespace Cheat