#include "pch.h"
#include "menu.h"
#include "imgui_impl_win32.h"
#include "cheat.h"
#include "d3d11_overlay.h"
#include "imgui_user.h"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace Menu
{
	static BOOL OnWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
	{
		Input::UpdateKeyState(uMsg, wParam, lParam);
		if (Input::IsKeyToggled(Options.MenuKey))
		{
			if (ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam)) return FALSE;
			switch (uMsg)
			{
			case WM_MOVE: case WM_SIZE: case WM_ACTIVATE: case WM_SETFOCUS:
			case WM_KILLFOCUS: case WM_PAINT: case WM_ERASEBKGND: case WM_ACTIVATEAPP:
			case WM_GETMINMAXINFO: case WM_WINDOWPOSCHANGING: case WM_WINDOWPOSCHANGED:
			case WM_NCCALCSIZE: case WM_NCHITTEST: case WM_NCPAINT: case WM_NCACTIVATE:
			case WM_SIZING: case WM_MOVING: break;
			default: return FALSE;
			}
		}
		return TRUE;
	}

	static void ApplyTheme()
	{
		ImGuiStyle& s = ImGui::GetStyle();
		s.WindowRounding = s.ChildRounding = s.PopupRounding = s.TabRounding = 0;
		s.FrameRounding = s.GrabRounding = s.ScrollbarRounding = 2;
		s.WindowBorderSize = s.ChildBorderSize = 1; s.FrameBorderSize = 0;
		s.WindowPadding = { 0,0 }; s.FramePadding = { 10,5 };
		s.ItemSpacing = { 8,6 }; s.ItemInnerSpacing = { 6,4 };
		s.IndentSpacing = 14; s.ScrollbarSize = 6; s.GrabMinSize = 6;
		ImVec4* c = s.Colors;
		c[ImGuiCol_Text] = { 0.92f,0.85f,0.85f,1 };
		c[ImGuiCol_TextDisabled] = { 0.45f,0.25f,0.25f,1 };
		c[ImGuiCol_WindowBg] = { 0.05f,0.01f,0.01f,1 };
		c[ImGuiCol_ChildBg] = { 0.07f,0.02f,0.02f,1 };
		c[ImGuiCol_PopupBg] = { 0.07f,0.01f,0.01f,0.97f };
		c[ImGuiCol_Border] = { 0.28f,0.05f,0.05f,1 };
		c[ImGuiCol_BorderShadow] = { 0,0,0,0 };
		c[ImGuiCol_FrameBg] = { 0.10f,0.03f,0.03f,1 };
		c[ImGuiCol_FrameBgHovered] = { 0.18f,0.04f,0.04f,1 };
		c[ImGuiCol_FrameBgActive] = { 0.22f,0.05f,0.05f,1 };
		c[ImGuiCol_TitleBg] = { 0.03f,0.01f,0.01f,1 };
		c[ImGuiCol_TitleBgActive] = { 0.03f,0.01f,0.01f,1 };
		c[ImGuiCol_TitleBgCollapsed] = { 0.03f,0.01f,0.01f,0.8f };
		c[ImGuiCol_MenuBarBg] = { 0.05f,0.01f,0.01f,1 };
		c[ImGuiCol_ScrollbarBg] = { 0.04f,0.01f,0.01f,1 };
		c[ImGuiCol_ScrollbarGrab] = { 0.50f,0.08f,0.08f,1 };
		c[ImGuiCol_ScrollbarGrabHovered] = { 0.65f,0.10f,0.10f,1 };
		c[ImGuiCol_ScrollbarGrabActive] = { 0.80f,0.12f,0.12f,1 };
		c[ImGuiCol_CheckMark] = { 0.90f,0.15f,0.15f,1 };
		c[ImGuiCol_SliderGrab] = { 0.75f,0.10f,0.10f,1 };
		c[ImGuiCol_SliderGrabActive] = { 0.95f,0.15f,0.15f,1 };
		c[ImGuiCol_Button] = { 0.35f,0.05f,0.05f,1 };
		c[ImGuiCol_ButtonHovered] = { 0.55f,0.08f,0.08f,1 };
		c[ImGuiCol_ButtonActive] = { 0.75f,0.12f,0.12f,1 };
		c[ImGuiCol_Header] = { 0,0,0,0 };
		c[ImGuiCol_HeaderHovered] = { 0.22f,0.04f,0.04f,1 };
		c[ImGuiCol_HeaderActive] = { 0.30f,0.05f,0.05f,1 };
		c[ImGuiCol_Separator] = { 0.25f,0.04f,0.04f,1 };
		c[ImGuiCol_SeparatorHovered] = { 0.45f,0.07f,0.07f,1 };
		c[ImGuiCol_SeparatorActive] = { 0.65f,0.10f,0.10f,1 };
		c[ImGuiCol_ResizeGrip] = { 0.40f,0.06f,0.06f,0.6f };
		c[ImGuiCol_ResizeGripHovered] = { 0.60f,0.09f,0.09f,0.8f };
		c[ImGuiCol_ResizeGripActive] = { 0.85f,0.13f,0.13f,1 };
		c[ImGuiCol_Tab] = { 0.08f,0.02f,0.02f,1 };
		c[ImGuiCol_TabHovered] = { 0.35f,0.05f,0.05f,1 };
		c[ImGuiCol_TabActive] = { 0.30f,0.05f,0.05f,1 };
		c[ImGuiCol_TabUnfocused] = { 0.05f,0.01f,0.01f,1 };
		c[ImGuiCol_TabUnfocusedActive] = { 0.18f,0.03f,0.03f,1 };
		c[ImGuiCol_PlotLines] = { 0.85f,0.20f,0.20f,1 };
		c[ImGuiCol_PlotLinesHovered] = { 1.00f,0.30f,0.30f,1 };
		c[ImGuiCol_PlotHistogram] = { 0.75f,0.10f,0.10f,1 };
		c[ImGuiCol_PlotHistogramHovered] = { 0.95f,0.20f,0.20f,1 };
		c[ImGuiCol_TextSelectedBg] = { 0.60f,0.09f,0.09f,0.5f };
		c[ImGuiCol_DragDropTarget] = { 0.90f,0.15f,0.15f,0.9f };
		c[ImGuiCol_NavHighlight] = { 0.85f,0.13f,0.13f,1 };
		c[ImGuiCol_NavWindowingHighlight] = { 1,1,1,0.7f };
		c[ImGuiCol_NavWindowingDimBg] = { 0.8f,0.8f,0.8f,0.2f };
		c[ImGuiCol_ModalWindowDimBg] = { 0.1f,0,0,0.5f };
	}

	static void BF() { static bool d = false; if (!d) { ApplyTheme(); d = true; } Cheat::BeforeFrame(); }

	struct Tab { char L; const char* N; };
	static const Tab Tabs[] = {
		{'A',"Aimbot"     },
		{'E',"ESP"        },
		{'M',"Misc"       },
		{'V',"Visuals"    },
		{'S',"Settings"   },
		{'I',"Information"},
	};
	static const int TC = IM_ARRAYSIZE(Tabs);
	static int  CT = 0;
	static bool SK = false;

	static void InfoTab()
	{
		ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 14,14 });
		ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.75f, 0.60f, 0.60f, 1));
		ImGui::TextWrapped("Pipsi — Redmatch 2 cheat. Features may change at any time.");
		ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();
		ImGui::PopStyleColor();
		ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.85f, 0.14f, 0.14f, 1));
		ImGui::Text("Version"); ImGui::PopStyleColor(); ImGui::SameLine();
		ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.75f, 0.60f, 0.60f, 1));
		ImGui::Text("Nightly - " __DATE__); ImGui::PopStyleColor();
		ImGui::PopStyleVar();
	}

	static void OF()
	{
		// Plus de guard hIl2Cpp ici — le menu est accessible partout
		if (Input::IsKeyToggled(Options.MenuKey))
		{
			ImGui::SetNextWindowSize({ 820,540 }, ImGuiCond_FirstUseEver);
			ImGui::PushStyleColor(ImGuiCol_WindowBg, { 0.05f,0.01f,0.01f,1 });
			ImGui::PushStyleColor(ImGuiCol_Border, { 0.35f,0.06f,0.06f,1 });
			ImGui::PushStyleColor(ImGuiCol_TitleBg, { 0.03f,0.01f,0.01f,1 });
			ImGui::PushStyleColor(ImGuiCol_TitleBgActive, { 0.03f,0.01f,0.01f,1 });
			ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 0,0 });

			if (ImGui::Begin("##PW", nullptr,
				ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar |
				ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoCollapse))
			{
				ImDrawList* dl = ImGui::GetWindowDrawList();
				ImVec2 wp = ImGui::GetWindowPos(), ws = ImGui::GetWindowSize();
				dl->AddRect(wp, { wp.x + ws.x,wp.y + ws.y }, IM_COL32(90, 12, 12, 255), 0, 0, 1.2f);
				const float B = 30, SB = 160;

				// Top bar
				dl->AddRectFilled(wp, { wp.x + ws.x,wp.y + B }, IM_COL32(8, 2, 2, 255));
				dl->AddLine({ wp.x,wp.y + B }, { wp.x + ws.x,wp.y + B }, IM_COL32(90, 12, 12, 255));
				ImGui::SetCursorPos({ 12,(B - ImGui::GetFontSize()) * .5f });
				ImGui::PushStyleColor(ImGuiCol_Text, { 0.88f,0.88f,0.88f,1 }); ImGui::Text("Pipsi"); ImGui::PopStyleColor();
				ImGui::SameLine(0, 0);
				ImGui::PushStyleColor(ImGuiCol_Text, { 0.85f,0.14f,0.14f,1 }); ImGui::Text(" - Redmatch 2"); ImGui::PopStyleColor();

				// Sidebar
				ImGui::SetCursorPos({ 0,B });
				ImGui::PushStyleColor(ImGuiCol_ChildBg, { 0.04f,0.01f,0.01f,1 });
				ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { 0,0 });
				if (ImGui::BeginChild("##SB", { SB,ws.y - B }, ImGuiChildFlags_None))
				{
					ImDrawList* sdl = ImGui::GetWindowDrawList();
					ImGui::SetCursorPos({ 12,10 });
					ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.45f, 0.16f, 0.16f, 1));
					ImGui::TextUnformatted("MAIN"); ImGui::PopStyleColor();
					ImGui::Dummy({ 0,6 });
					for (int i = 0; i < TC; i++)
					{
						ImGui::PushID(i); bool sel = (CT == i); const float RH = 28;
						ImVec2 rm = ImGui::GetCursorScreenPos(), rx = { rm.x + SB,rm.y + RH };
						if (sel) { sdl->AddRectFilled(rm, rx, IM_COL32(55, 8, 8, 255)); sdl->AddRectFilled(rm, { rm.x + 3,rx.y }, IM_COL32(210, 28, 28, 255)); }
						float ty = rm.y + (RH - ImGui::GetFontSize()) * .5f;
						char lt[2] = { Tabs[i].L,'\0' };
						sdl->AddText({ rm.x + 10,ty }, sel ? IM_COL32(220, 35, 35, 255) : IM_COL32(110, 30, 30, 255), lt);
						sdl->AddText({ rm.x + 24,ty }, sel ? IM_COL32(230, 205, 205, 255) : IM_COL32(140, 90, 90, 255), Tabs[i].N);
						ImGui::PushStyleColor(ImGuiCol_Header, ImVec4(0, 0, 0, 0));
						ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImVec4(0.22f, 0.04f, 0.04f, 1));
						ImGui::PushStyleColor(ImGuiCol_HeaderActive, ImVec4(0.30f, 0.05f, 0.05f, 1));
						if (ImGui::Selectable("##r", sel, 0, { SB,RH })) CT = i;
						ImGui::PopStyleColor(3); ImGui::PopID();
					}
					float sh = ImGui::GetWindowHeight();
					ImGui::SetCursorPos({ 8,sh - 36 });
					ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, { 8,6 });
					ImGui::Toggle("Keys", &SK); ImGui::PopStyleVar();
					ImVec2 sp = ImGui::GetWindowPos(), ss = ImGui::GetWindowSize();
					sdl->AddLine({ sp.x + ss.x - 1,sp.y }, { sp.x + ss.x - 1,sp.y + ss.y }, IM_COL32(60, 10, 10, 255));
				}
				ImGui::EndChild();
				ImGui::PopStyleVar(); ImGui::PopStyleColor();

				// Content
				ImGui::SetCursorPos({ SB,B });
				ImGui::PushStyleColor(ImGuiCol_ChildBg, { 0.06f,0.015f,0.015f,1 });
				ImGui::PushStyleColor(ImGuiCol_Border, { 0.28f,0.05f,0.05f,1 });
				ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, { 12,12 });
				if (ImGui::BeginChild("##CT", { ws.x - SB,ws.y - B }, ImGuiChildFlags_Borders))
				{
					switch (CT)
					{
					case 0: Cheat::MenuAimbot();       break;
					case 1: Cheat::MenuESP();          break;
					case 2: Cheat::MenuMiscFeatures(); break;
					case 3: Cheat::MenuVisuals();      break;
					case 4: Cheat::MenuSettings();     break;
					case 5: InfoTab();                 break;
					}
				}
				ImGui::EndChild();
				ImGui::PopStyleVar(); ImGui::PopStyleColor(2);
			}
			ImGui::End();
			ImGui::PopStyleVar(); ImGui::PopStyleColor(4);
		}

		if (SK) ImGui::DrawKeyboardOverlay();

		// OnFrame uniquement si il2cpp est chargé
		if (hIl2Cpp) Cheat::OnFrame();
	}

	bool Setup()
	{
		if (!D3D11_Overlay::Setup(OnWndProc, BF, OF)) return FALSE;
		if (!Cheat::Setup()) return FALSE;
		return TRUE;
	}
}