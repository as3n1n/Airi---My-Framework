#pragma once
#include "global.h"
#include "imgui.h"
#include "imgui_user.h"

namespace MenuSettings
{
    void Menu();
    void BeforeFrame();
    void OnFrame();
    bool Setup();
}