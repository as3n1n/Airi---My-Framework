#pragma once
#include "rm2_offsets.h"
#include "engine.h"
#include "imgui.h"
#include <math.h>

// ── Raw read / write / pointer ────────────────────────────────────────────
template<typename T> inline T    RM_R(void* b, uint32_t o) { return *reinterpret_cast<T*>((PBYTE)b + o); }
template<typename T> inline T* RM_P(void* b, uint32_t o) { return *reinterpret_cast<T**>((PBYTE)b + o); }
template<typename T> inline void RM_W(void* b, uint32_t o, T v) { *reinterpret_cast<T*>((PBYTE)b + o) = v; }

// ── Shorthand types ───────────────────────────────────────────────────────
using RM2_Vec3 = UnityEngine_Vector3_o;
using RM2_GO = UnityEngine_GameObject_o;
using RM2_Cam = UnityEngine_Camera_o;
using RM2_TR = UnityEngine_Transform_o;
using RM2_RB = UnityEngine_Rigidbody_o;
using RM2_PC = PlayerController_o;
using RM2_MI = MyceliumIdentity_o;
using RM2_HS = HealthSyncer_o;

// ── Get local PlayerController ────────────────────────────────────────────
// dump.cs confirme : public static PlayerController LocalInstance; // 0x38
inline RM2_PC* RM_GetLocalPC()
{
    if (!hIl2Cpp) return nullptr;
    __try
    {
        Il2CppClass* c = RM2_GetClass(RM2_PC_TYPEIDX);
        if (!c || !c->static_fields) return nullptr;
        // 0x38 = offset de LocalInstance dans PlayerController_StaticFields
        return *reinterpret_cast<RM2_PC**>((PBYTE)c->static_fields + 0x38);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
}

// ── Get local Camera ──────────────────────────────────────────────────────
inline RM2_Cam* RM_GetCam()
{
    if (!hIl2Cpp) return nullptr;
    __try
    {
        RM2_PC* pc = RM_GetLocalPC();
        if (pc)
        {
            RM2_Cam* cam = pc->fields.cam;
            if (cam) return cam;
        }
        // Fallback Camera.get_main
        return ((RM2_Cam * (*)())((PBYTE)hIl2Cpp + 0x175E6E0))();
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
}

// ── Get local Rigidbody ───────────────────────────────────────────────────
inline RM2_RB* RM_GetRB()
{
    if (!hIl2Cpp) return nullptr;
    __try
    {
        RM2_PC* pc = RM_GetLocalPC();
        if (!pc) return nullptr;
        return pc->fields._60____________________________k__BackingField;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
}

// ── Get local GameObject ──────────────────────────────────────────────────
inline RM2_GO* RM_GetLocalGO()
{
    if (!hIl2Cpp) return nullptr;
    __try
    {
        RM2_PC* pc = RM_GetLocalPC();
        if (!pc) return nullptr;
        return pc->fields.cameraHolder;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
}

// ── Get all MyceliumIdentity ──────────────────────────────────────────────
inline MyceliumIdentity_array* RM_GetAllMI()
{
    if (!hIl2Cpp) return nullptr;
    __try
    {
        return ((MyceliumIdentity_array * (*)())((PBYTE)hIl2Cpp + RVA_MI_GETALL))();
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
}

// ── Get HealthSyncer from GameObject ─────────────────────────────────────
inline RM2_HS* RM_GetHS(RM2_GO* go)
{
    if (!go || !hIl2Cpp) return nullptr;
    __try
    {
        using GetCompFn = void* (*)(void*, Il2CppClass*);
        Il2CppClass* hsClass = RM2_GetClass(RM2_HS_TYPEIDX);
        if (!hsClass) return nullptr;
        return (RM2_HS*)((GetCompFn)((PBYTE)hIl2Cpp + 0x3AD3A0))(go, hsClass);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return nullptr; }
}

// ── Get player name ───────────────────────────────────────────────────────
inline void RM_GetName(RM2_MI* mi, char* buf, int len)
{
    buf[0] = '\0';
    if (!mi) return;
    __try
    {
        auto* strObj = mi->fields.___________________________k__BackingField;
        if (!strObj) return;
        wchar_t* w = (wchar_t*)((PBYTE)strObj + 0x14);
        int i = 0;
        while (w[i] && i < len - 1) { buf[i] = (char)w[i]; i++; }
        buf[i] = '\0';
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { buf[0] = '\0'; }
}

// ── World to Screen ───────────────────────────────────────────────────────
inline bool RM_W2S(RM2_Cam* cam, RM2_Vec3 wp, float& sx, float& sy)
{
    if (!cam || !hIl2Cpp) return false;
    __try
    {
        RM2_Vec3 sp = {};
        using W2SFn = void(*)(void*, RM2_Vec3*, RM2_Vec3*);
        ((W2SFn)((PBYTE)hIl2Cpp + 0x175DFF0))(cam, &wp, &sp);
        if (sp.fields.z <= 0) return false;
        ImGuiIO& io = ImGui::GetIO();
        sx = sp.fields.x;
        sy = io.DisplaySize.y - sp.fields.y;
        return sx > 0 && sx < io.DisplaySize.x && sy > 0 && sy < io.DisplaySize.y;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) { return false; }
}

// ── Distance ──────────────────────────────────────────────────────────────
inline float RM_Dist(RM2_Vec3 a, RM2_Vec3 b)
{
    float dx = a.fields.x - b.fields.x;
    float dy = a.fields.y - b.fields.y;
    float dz = a.fields.z - b.fields.z;
    return sqrtf(dx * dx + dy * dy + dz * dz);
}

// ── Get Transform position ────────────────────────────────────────────────
inline RM2_Vec3 RM_GetPos(RM2_GO* go)
{
    RM2_Vec3 v = {};
    if (!go || !hIl2Cpp) return v;
    __try
    {
        using GetTrFn = RM2_TR * (*)(void*);
        using GetPosFn = void(*)(void*, RM2_Vec3*);
        RM2_TR* tr = ((GetTrFn)((PBYTE)hIl2Cpp + 0x15B0290))(go);
        if (!tr) return v;
        ((GetPosFn)((PBYTE)hIl2Cpp + 0x15B0750))(tr, &v);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
    return v;
}

// ── Rigidbody helpers ─────────────────────────────────────────────────────
inline void RM_RB_Gravity(RM2_RB* rb, bool en)
{
    if (!rb || !hIl2Cpp) return;
    __try { ((void(*)(void*, bool))((PBYTE)hIl2Cpp + RVA_RB_SET_GRAVITY))(rb, en); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}

inline void RM_RB_Kinema(RM2_RB* rb, bool k)
{
    if (!rb || !hIl2Cpp) return;
    __try { ((void(*)(void*, bool))((PBYTE)hIl2Cpp + RVA_RB_SET_KINEMA))(rb, k); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}

inline RM2_Vec3 RM_RB_GetVel(RM2_RB* rb)
{
    RM2_Vec3 v = {};
    if (!rb || !hIl2Cpp) return v;
    __try { ((void(*)(void*, RM2_Vec3*))((PBYTE)hIl2Cpp + RVA_RB_GET_VEL))(rb, &v); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
    return v;
}

inline void RM_RB_SetVel(RM2_RB* rb, RM2_Vec3 v)
{
    if (!rb || !hIl2Cpp) return;
    __try { ((void(*)(void*, RM2_Vec3*))((PBYTE)hIl2Cpp + RVA_RB_SET_VEL))(rb, &v); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}

inline void RM_RB_SetPos(RM2_RB* rb, RM2_Vec3 v)
{
    if (!rb || !hIl2Cpp) return;
    __try { ((void(*)(void*, RM2_Vec3*))((PBYTE)hIl2Cpp + RVA_RB_SET_POS))(rb, &v); }
    __except (EXCEPTION_EXECUTE_HANDLER) {}
}