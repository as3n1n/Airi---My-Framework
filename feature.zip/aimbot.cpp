#include "pch.h"
#include "cheat.h"
#include "rm2_helpers.h"
#include "global.h"
#include "imgui.h"
#include "imgui_user.h"
#include <math.h>
#include <algorithm>

namespace Cheat
{
	bool          AB_Enable = false;
	bool          AB_CheckVisible = false;
	bool          AB_DisregardPing = true;
	bool          AB_ShieldBypass = false;
	bool          AB_CheckShield = false;
	bool          AB_TeleKill = false;
	float         AB_FOV = 10.0f;
	unsigned char AB_Key = VK_RBUTTON;
	bool          AB_KeyHeld = false;

	static float AngleTo(RM2_Cam* cam, RM2_Vec3 target)
	{
		float sx, sy;
		if (!RM_W2S(cam, target, sx, sy)) return 999.f;
		ImGuiIO& io = ImGui::GetIO();
		float dx = sx - io.DisplaySize.x * 0.5f;
		float dy = sy - io.DisplaySize.y * 0.5f;
		float diag = sqrtf(io.DisplaySize.x * io.DisplaySize.x +
			io.DisplaySize.y * io.DisplaySize.y);
		return sqrtf(dx * dx + dy * dy) / diag * 180.0f;
	}

	static void LookAt(RM2_PC* pc, RM2_Vec3 target)
	{
		if (!pc || !hIl2Cpp) return;
		RM2_GO* holder = pc->fields.cameraHolder; if (!holder) return;
		using GetTrFn = RM2_TR * (*)(void*);
		RM2_TR* tr = ((GetTrFn)((PBYTE)hIl2Cpp + 0x15B0290))(holder);
		if (!tr) return;
		using LookFn = void(*)(void*, RM2_Vec3*);
		((LookFn)((PBYTE)hIl2Cpp + 0x15B0890))(tr, &target);
	}

	void Aimbot_OnFrame()
	{
		if (!AB_Enable) return;
		bool down = AB_Key ? (GetAsyncKeyState(AB_Key) & 0x8000) != 0 : true;
		if (!down) return;

		RM2_PC* pc = RM_GetLocalPC(); if (!pc) return;
		RM2_Cam* cam = RM_GetCam();     if (!cam) return;
		RM2_GO* lgo = RM_GetLocalGO();
		RM2_Vec3 lp = {}; if (lgo) lp = RM_GetPos(lgo);

		MyceliumIdentity_array* arr = RM_GetAllMI(); if (!arr) return;

		RM2_MI* best = nullptr;
		RM2_Vec3 bestPos = {};
		float    bestAng = AB_FOV;

		for (il2cpp_array_size_t i = 0; i < arr->max_length; i++)
		{
			RM2_MI* mi = arr->m_Items[i]; if (!mi) continue;
			if (!mi->fields.player) continue;
			RM2_GO* go = RM_P<RM2_GO>(mi, 0x10);
			if (!go || go == lgo) continue;

			if (AB_CheckShield)
			{
				RM2_HS* hs = RM_GetHS(go);
				if (hs && hs->fields.health <= 0) continue;
			}

			RM2_Vec3 head = RM_GetPos(go);
			head.fields.y += 1.5f;
			float ang = AngleTo(cam, head);
			if (ang < bestAng) { bestAng = ang; best = mi; bestPos = head; }
		}

		if (!best) return;

		if (AB_TeleKill)
		{
			RM2_RB* rb = RM_GetRB();
			if (rb)
			{
				RM2_Vec3 tp = bestPos;
				tp.fields.y += 1.0f;
				RM_RB_SetPos(rb, tp);
			}
		}
		else
		{
			LookAt(pc, bestPos);
		}
	}

	void MenuAimbot()
	{
		ImGui::Toggle("Enable Aimbot", &AB_Enable);
		ImGui::Spacing(); ImGui::Separator(); ImGui::Spacing();

		ImGui::BeginGroupPanel("Settings", ImVec2(-FLT_MIN, 0));
		ImGui::Toggle("Check Visible", &AB_CheckVisible);
		ImGui::Toggle("Disregard Ping", &AB_DisregardPing);
		ImGui::Toggle("Check Shield", &AB_CheckShield);
		ImGui::Toggle("Shield Bypass", &AB_ShieldBypass);
		ImGui::Toggle("TeleKill", &AB_TeleKill);
		ImGui::Spacing();
		ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1));
		ImGui::Text("Field of View"); ImGui::PopStyleColor(); ImGui::SameLine();
		ImGui::SetNextItemWidth(130);
		ImGui::SliderFloat("##ABFOV", &AB_FOV, 1.0f, 90.0f, "%.1f deg");
		ImGui::Spacing();
		ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1));
		ImGui::Text("Hold Key"); ImGui::PopStyleColor(); ImGui::SameLine();
		ImGui::SmallHotkey("##ABK", &AB_Key);
		ImGui::EndGroupPanel();
	}
} // namespace Cheat