#pragma once
#include <stdint.h>

// ============================================================
//  Redmatch 2 — offsets from dump.cs
// ============================================================

// ── TypeDefinitionIndex ──────────────────────────────────────
#define RM2_PC_TYPEIDX   8453   // PlayerController
#define RM2_MI_TYPEIDX   8388   // MyceliumIdentity
#define RM2_HS_TYPEIDX   7512   // HealthSyncer

// ── PlayerController instance fields ────────────────────────
#define PC_CAMERA_HOLDER    0x30   // GameObject*
#define PC_SHIELD_OBJECT    0x38   // GameObject*
#define PC_CAM              0x40   // Camera*
#define PC_ITEMS            0x60   // Item[]
#define PC_RENDERER         0xB8   // Renderer*
#define PC_BULLET_SPREAD    0x168  // float
#define PC_RIGIDBODY        0x180  // Rigidbody*
#define PC_MYCELIUM_ID      0x188  // MyceliumIdentity*

// ── PlayerController static fields ──────────────────────────
#define PC_STATIC_LOCAL     0x38   // PlayerController* (LocalInstance)

// ── Item instance fields ─────────────────────────────────────
#define ITEM_INFO           0x18   // ItemInfo*
#define ITEM_BULLET_SPREAD  0x30   // float
#define ITEM_AMMO           0x34   // int (raw)
#define ITEM_TOTAL_AMMO     0x3C   // int (raw)
#define ITEM_NEXT_USE_TIME  0x44   // float  → set 0 for rapid fire

// ── ItemInfo fields ──────────────────────────────────────────
#define II_USE_DELAY        0x28   // float
#define II_PRIMARY_SHOT     0x30   // ItemInfo.ShotInfo*
#define II_RELOAD_TIME      0x40   // float
#define II_USES_AMMO        0x44   // bool
#define II_MAGAZINE_SIZE    0x48   // int
#define II_MAX_SPREAD       0x60   // float
#define II_SPREAD_DECAY     0x64   // float
#define II_NORMAL_SPREAD    0x68   // float
#define II_ADS_SPREAD       0x6C   // float
#define II_MOV_SPREAD_MULT  0x70   // float  movementSpreadMultiplier
#define II_NOSCOPE          0xBC   // bool

// ── ItemInfo.ShotInfo fields ─────────────────────────────────
#define SI_BULLET_SPREAD    0x1C   // float
#define SI_ADS_SPREAD       0x20   // float
#define SI_CAM_SHAKE        0x30   // float
#define SI_ADS_CAM_SHAKE    0x34   // float
#define SI_AUTOFIRE         0x48   // bool
#define SI_DMG_MULTIPLIER   0x50   // float

// ── HealthSyncer fields ──────────────────────────────────────
#define HS_MAX_HP           0x20   // int
#define HS_HP               0x24   // int

// ── MyceliumIdentity fields ──────────────────────────────────
#define MI_PLAYER           0x18   // bool
#define MI_NAME_STR         0x20   // System::String* (NIname backing field)
#define MI_NET_ID           0x28   // int

// ── RVAs (offset from GameAssembly.dll base) ─────────────────
// Time
#define RVA_TIME_GET_SCALE  0x15AD810
#define RVA_TIME_SET_SCALE  0x15AD910
// Application
#define RVA_APP_SET_FPS     0x175A5B0
// Camera
#define RVA_CAM_GET_FOV     0x175E600
#define RVA_CAM_SET_FOV     0x175F030
// Rigidbody
#define RVA_RB_GET_VEL      0x2251D50
#define RVA_RB_SET_VEL      0x22521F0
#define RVA_RB_SET_GRAVITY  0x2252150   // set_useGravity(bool)
#define RVA_RB_SET_KINEMA   0x2251F70   // set_isKinematic(bool)
#define RVA_RB_SET_POS      0x2252060   // set_position(Vector3)
// MyceliumIdentity static
#define RVA_MI_GETALL       0xC00850    // MyceliumIdentity[] GetAll()