#include "pch.h"
#include "fov_changer.h"
#include "global.h"
#include "imgui.h"
#include "imgui_user.h"

// RVA_CAM_GET_FOV = 0x175E600
// RVA_CAM_SET_FOV = 0x175F030

namespace FovChanger
{
    static float GetFOV()
    {
        if (!hIl2Cpp) return 60.f;
        void* cam = ((void* (*)())((PBYTE)hIl2Cpp + 0x175E6E0))(); // Camera.get_main
        if (!cam) return 60.f;
        return ((float(*)(void*))((PBYTE)hIl2Cpp + 0x175E600))(cam);
    }

    static void SetFOV(float fov)
    {
        if (!hIl2Cpp) return;
        void* cam = ((void* (*)())((PBYTE)hIl2Cpp + 0x175E6E0))();
        if (!cam) return;
        ((void(*)(void*, float))((PBYTE)hIl2Cpp + 0x175F030))(cam, fov);
    }

    void Menu()
    {
        ImGui::BeginGroupPanel("FOV Changer", ImVec2(-FLT_MIN, 0));
        bool prev = Options.FovChanger;
        ImGui::Toggle("Enable", &Options.FovChanger);
        if (Options.FovChanger)
        {
            ImGui::Spacing();
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1));
            ImGui::Text("FOV"); ImGui::PopStyleColor(); ImGui::SameLine();
            ImGui::SetNextItemWidth(140);
            ImGui::SliderFloat("##FOV", &Options.FovChangerValue, 30.f, 180.f, "%.0f");
            ImGui::Spacing();
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1));
            ImGui::Text("Hotkey"); ImGui::PopStyleColor(); ImGui::SameLine();
            ImGui::SmallHotkey("##FOVK", &Options.FovChangerKey);
        }
        else if (prev && !Options.FovChanger)
        {
            SetFOV(60.f);
        }
        ImGui::EndGroupPanel();
    }

    void BeforeFrame() {}

    void OnFrame()
    {
        if (!hIl2Cpp) return;
        if (Options.FovChangerKey)
        {
            bool d = (GetAsyncKeyState(Options.FovChangerKey) & 0x8000) != 0;
            if (d && !Options.FovChangerKeyHeld)
            {
                Options.FovChangerKeyHeld = true;
                Options.FovChanger = !Options.FovChanger;
                if (!Options.FovChanger) SetFOV(60.f);
            }
            else if (!d) Options.FovChangerKeyHeld = false;
        }
        if (Options.FovChanger) SetFOV(Options.FovChangerValue);
    }

    bool Setup() { return TRUE; }
}