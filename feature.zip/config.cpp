#include "pch.h"
#include "config.h"
#include "global.h"
#include <windows.h>
#include <string>

namespace Config
{
    static std::string GetConfigPath(int slot = 0)
    {
        char path[MAX_PATH];
        GetModuleFileNameA(nullptr, path, MAX_PATH);
        std::string dir(path);
        dir = dir.substr(0, dir.find_last_of("\\/"));
        if (slot == 0)
            return dir + "\\pipsi_config.bin";
        return dir + "\\pipsi_config_" + std::to_string(slot) + ".bin";
    }

    static void Save(int slot = 0)
    {
        std::string p = GetConfigPath(slot);
        HANDLE hf = CreateFileA(p.c_str(), GENERIC_WRITE, 0, nullptr,
            CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (hf == INVALID_HANDLE_VALUE) return;
        DWORD written = 0;
        WriteFile(hf, &Options, sizeof(OPTIONS), &written, nullptr);
        CloseHandle(hf);
    }

    static void Load(int slot = 0)
    {
        std::string p = GetConfigPath(slot);
        HANDLE hf = CreateFileA(p.c_str(), GENERIC_READ, FILE_SHARE_READ,
            nullptr, OPEN_EXISTING, 0, nullptr);
        if (hf == INVALID_HANDLE_VALUE) return;
        DWORD read = 0;
        ReadFile(hf, &Options, sizeof(OPTIONS), &read, nullptr);
        CloseHandle(hf);
    }

    void Menu()
    {
        ImGui::BeginGroupPanel("Config", ImVec2(-FLT_MIN, 0.0f));

        if (ImGui::Button("Save Config", ImVec2(-FLT_MIN, 0.0f)))
            Save();

        ImGui::Spacing();

        if (ImGui::Button("Load Config", ImVec2(-FLT_MIN, 0.0f)))
            Load();

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.45f, 0.25f, 0.25f, 1));
        ImGui::TextWrapped("Config is saved as pipsi_config.bin next to the DLL.");
        ImGui::PopStyleColor();

        ImGui::EndGroupPanel();
    }

    void MenuConfigProfiles()
    {
        static int s_Selected = 1;

        ImGui::BeginGroupPanel("Config Profiles", ImVec2(-FLT_MIN, 0.0f));

        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.85f, 0.85f, 0.92f, 1));
        ImGui::Text("Profile"); ImGui::PopStyleColor(); ImGui::SameLine();
        ImGui::SetNextItemWidth(80);
        ImGui::SliderInt("##profslot", &s_Selected, 1, 5, "Slot %d");

        ImGui::Spacing();

        if (ImGui::Button("Save Profile", ImVec2(-FLT_MIN, 0.0f)))
            Save(s_Selected);

        ImGui::Spacing();

        if (ImGui::Button("Load Profile", ImVec2(-FLT_MIN, 0.0f)))
            Load(s_Selected);

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.45f, 0.25f, 0.25f, 1));
        ImGui::TextWrapped("Profiles saved as pipsi_config_1.bin ... pipsi_config_5.bin");
        ImGui::PopStyleColor();

        ImGui::EndGroupPanel();
    }

    void BeforeFrame() {}
    void OnFrame() {}

    bool Setup()
    {
        Load();
        return TRUE;
    }
}