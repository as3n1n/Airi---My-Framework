#include "pch.h"
#include "menu_settings.h"

namespace MenuSettings
{
    void Menu()
    {
        // ── Menu Key ─────────────────────────────────────────────────────
        ImGui::BeginGroupPanel("Menu Key", ImVec2(-FLT_MIN, 0.0f));

        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1.00f));
        ImGui::TextUnformatted("Toggle Key");
        ImGui::PopStyleColor();
        ImGui::SameLine();
        ImGui::SmallHotkey("##MenuHotkey", &Options.MenuKey);

        // Prevent left mouse button being bound (would lock the menu)
        if (Options.MenuKey == VK_LBUTTON)
            Options.MenuKey = 0;

        ImGui::Spacing();
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.45f, 0.25f, 0.25f, 1.00f));
        ImGui::TextWrapped("Default: INSERT. Click the button then press a key to rebind.");
        ImGui::PopStyleColor();

        ImGui::EndGroupPanel();

        ImGui::Spacing();

        // ── Scale ─────────────────────────────────────────────────────────
        ImGui::BeginGroupPanel("Menu Scale", ImVec2(-FLT_MIN, 0.0f));

        ImGui::Toggle("Custom Scale", &Options.MenuCustomScale);

        if (Options.MenuCustomScale)
        {
            ImGui::Spacing();
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.92f, 0.85f, 0.85f, 1.00f));
            ImGui::Text("Scale");
            ImGui::PopStyleColor();
            ImGui::SameLine();
            ImGui::SetNextItemWidth(150.0f);
            ImGui::SliderFloat("##ScaleVal", &Options.MenuCustomScaleValue,
                0.5f, 4.0f, "%.2f");
            ImGui::SameLine();
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.75f, 0.60f, 0.60f, 1.00f));
            ImGui::Text("x%.2f", Options.MenuCustomScaleValue);
            ImGui::PopStyleColor();
        }

        ImGui::EndGroupPanel();
    }

    void BeforeFrame()
    {
        float scale = Options.MenuCustomScale ? Options.MenuCustomScaleValue : 1.0f;

        ImGuiStyle& style = ImGui::GetStyle();

        if (style.FontScaleDpi != scale)
        {
            ImGuiStyle newStyle;
            newStyle.ScaleAllSizes(scale);
            newStyle.FontScaleDpi = scale;
            style = newStyle;
        }
    }

    void OnFrame() {}
    bool Setup() { return TRUE; }
}